#!/usr/bin/env python
# coding: utf-8

# # Breast Cancer Classification using K-Nearest Neighbors (KNN)
# 
# **Assignment 4 – AI/ML**
# 
# **Name:** AADISH ADLAK
# **Registration Number:** 23BCE10681
# **Application Number:** IN26010985
# **Batch Number:** 9A
# **Email:** adlakaadish@gmail.com
# 
# **Dataset:** Breast Cancer Wisconsin (Diagnostic) Data Set
# Kaggle: https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data
# 
# ---
# This notebook classifies breast tumors as **Malignant (M)** or **Benign (B)** using a K-Nearest Neighbors classifier, following the 5 tasks of the assignment.

# ## Setup: Import Libraries

# In[1]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                              f1_score, confusion_matrix, classification_report)

sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (7, 5)
np.random.seed(42)
print("Libraries imported successfully.")


# ## Task 1: Data Understanding (2 Marks)
# 
# We load the **Breast Cancer Wisconsin (Diagnostic)** dataset. The CSV (`data/breast_cancer_data.csv`) included in this
# repository was generated from the same canonical UCI/Kaggle source (`sklearn.datasets.load_breast_cancer`,
# which ships the identical Wisconsin Diagnostic measurements) so the notebook runs end-to-end without any
# external download. If you prefer, you can instead download `data.csv` directly from the
# [Kaggle page](https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data) and place it at
# `data/breast_cancer_data.csv` — the column names match, so the rest of the notebook works unchanged.

# In[2]:


# 1. Load the dataset using Pandas
df = pd.read_csv("data/breast_cancer_data.csv")

# 2. Display the first five records
df.head()


# In[3]:


# 3. Identify numerical features and target variable
target_variable = "diagnosis"
numerical_features = [col for col in df.columns if col not in ["id", target_variable]]

print(f"Target variable: '{target_variable}' (M = Malignant, B = Benign)")
print(f"Number of numerical features: {len(numerical_features)}")
print("\nNumerical features:")
for f in numerical_features:
    print(" -", f)


# In[4]:


# 4. Dataset information
df.info()


# In[5]:


# Summary statistics
df.describe().T


# In[6]:


# Class distribution
print(df['diagnosis'].value_counts())

plt.figure(figsize=(5,4))
sns.countplot(x='diagnosis', data=df, palette=['#4C72B0', '#DD8452'])
plt.title("Class Distribution: Malignant (M) vs Benign (B)")
plt.xlabel("Diagnosis")
plt.ylabel("Count")
plt.tight_layout()
plt.savefig("images/class_distribution.png", dpi=120)
plt.show()


# ## Task 2: Data Preprocessing (2 Marks)

# In[7]:


# Check for missing values
missing = df.isnull().sum()
print("Missing values per column:")
print(missing[missing > 0] if missing.sum() > 0 else "No missing values found in the dataset.")


# In[8]:


# Remove unnecessary columns
# 'id' is just a row identifier and carries no predictive information -> drop it.
if 'id' in df.columns:
    df = df.drop(columns=['id'])

# If an 'Unnamed: 32' empty column exists (common in the raw Kaggle CSV export), drop it too.
df = df.loc[:, ~df.columns.str.contains('^Unnamed')]

print("Columns after cleanup:", df.shape[1])


# In[9]:


# Encode the target variable: Malignant -> 1, Benign -> 0
le = LabelEncoder()
df['diagnosis_encoded'] = le.fit_transform(df['diagnosis'])  # B=0, M=1
print(dict(zip(le.classes_, le.transform(le.classes_))))

X = df.drop(columns=['diagnosis', 'diagnosis_encoded'])
y = df['diagnosis_encoded']


# In[10]:


# Split the dataset into 80% training and 20% testing (before scaling, to avoid data leakage)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.20, random_state=42, stratify=y
)
print("Training set size:", X_train.shape)
print("Testing set size :", X_test.shape)


# In[11]:


# Normalize / standardize the feature values
# KNN is a distance-based algorithm, so features must be on the same scale.
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)   # fit only on training data
X_test_scaled = scaler.transform(X_test)         # transform test data using the same scaler

X_train_scaled = pd.DataFrame(X_train_scaled, columns=X.columns)
X_test_scaled = pd.DataFrame(X_test_scaled, columns=X.columns)
X_train_scaled.head()


# ## Task 3: Model Development (3 Marks)

# In[12]:


# 1 & 2. Train a KNN classifier with K = 5
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train_scaled, y_train)
print("KNN model trained with K = 5")


# In[13]:


# 3. Predict the class labels for the test dataset
y_pred = knn.predict(X_test_scaled)
print("Predictions (first 20):", y_pred[:20])
print("Actual      (first 20):", y_test.values[:20])


# ## Task 4: Model Evaluation (2 Marks)

# In[14]:


acc = accuracy_score(y_test, y_pred)
prec = precision_score(y_test, y_pred)
rec = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

print(f"Accuracy  : {acc:.4f}")
print(f"Precision : {prec:.4f}")
print(f"Recall    : {rec:.4f}")
print(f"F1-Score  : {f1:.4f}")

print("\nFull classification report:")
print(classification_report(y_test, y_pred, target_names=['Benign (B)', 'Malignant (M)']))


# In[15]:


# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)

plt.figure(figsize=(5.5, 4.5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=['Benign (B)', 'Malignant (M)'],
            yticklabels=['Benign (B)', 'Malignant (M)'])
plt.xlabel("Predicted Label")
plt.ylabel("True Label")
plt.title("Confusion Matrix - KNN (K=5)")
plt.tight_layout()
plt.savefig("images/confusion_matrix.png", dpi=120)
plt.show()


# In[16]:


# Effect of K on accuracy (extra analysis to support the observations below)
k_values = range(1, 21)
accuracies = []
for k in k_values:
    model = KNeighborsClassifier(n_neighbors=k)
    model.fit(X_train_scaled, y_train)
    pred = model.predict(X_test_scaled)
    accuracies.append(accuracy_score(y_test, pred))

plt.figure(figsize=(7,4.5))
plt.plot(list(k_values), accuracies, marker='o', color='#4C72B0')
plt.axvline(x=5, color='red', linestyle='--', label='K = 5 (used in this assignment)')
plt.xlabel("Value of K")
plt.ylabel("Test Accuracy")
plt.title("KNN Accuracy vs. Number of Neighbors (K)")
plt.xticks(list(k_values))
plt.legend()
plt.tight_layout()
plt.savefig("images/k_vs_accuracy.png", dpi=120)
plt.show()

best_k = list(k_values)[int(np.argmax(accuracies))]
print(f"Best K found in range 1-20: {best_k} with accuracy {max(accuracies):.4f}")


# ### Observations
# 
# 1. **High overall accuracy:** The KNN model with K = 5 achieves strong accuracy (typically ~95-97%) on the test
#    set, showing that the diagnostic measurements (radius, texture, perimeter, area, smoothness, etc.) are highly
#    informative for separating malignant from benign tumors after standardization.
# 2. **Recall on the Malignant class matters most:** In a medical diagnosis setting, a *false negative* (predicting
#    Benign when the tumor is actually Malignant) is far more costly than a false positive. The confusion matrix and
#    recall score for the Malignant class should be inspected closely — the model here maintains high recall,
#    meaning very few malignant cases are missed.
# 3. **Choice of K affects performance:** The K-vs-accuracy plot shows that accuracy is not monotonic in K — very
#    small K (e.g., K=1) can overfit to noise, while very large K can oversmooth the decision boundary and mix in
#    points from the wrong class. K = 5 turns out to be a reasonable, near-optimal choice for this dataset.

# ## Task 5: Conclusion (1 Mark)

# In this project, a K-Nearest Neighbors classifier was built to distinguish malignant from benign breast
# tumors using the Breast Cancer Wisconsin (Diagnostic) dataset. After cleaning the data, encoding the target
# variable, and standardizing all 30 numerical features, the KNN model (K = 5) achieved high accuracy, precision,
# recall, and F1-score on the held-out test set, confirming that tumor measurements such as radius, texture, and
# concavity carry strong diagnostic signal. Feature scaling proved essential for KNN, since it is a distance-based
# algorithm: without standardization, features with larger numeric ranges (like *area*) would dominate the
# Euclidean distance calculation and distort the neighbor search, even though smaller-scale features (like
# *smoothness*) can be equally predictive. One key limitation of KNN is its computational cost at prediction
# time — it must compute the distance from a new point to every training sample, making it slow and
# memory-intensive on very large datasets, and its performance also degrades in high-dimensional feature spaces
# due to the curse of dimensionality.
